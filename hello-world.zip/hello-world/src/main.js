import Vue from "vue";
import App from "./App.vue";

Vue.config.productionTip = false;

new Vue({
  render: h => h(App)
}).$mount(window.vueTarget || "#app");

if (window.parent) {
  const assets = [
    ...document.querySelectorAll('head > link[rel="preload"]')
  ].map(x => x.href.substr(window.location.href.length));
  window.parent.postMessage(JSON.stringify(assets), "*");
}
